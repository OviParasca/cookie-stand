//
//  CanvasView.h
//  FaceTrackerDemo
//
//  Created by Jack Song on 2/20/16.
//  Copyright © 2016 ReadFace. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CanvasView : UIView

#define POINTS_KEY @"POINTS_KEY"
#define RECT_KEY   @"RECT_KEY"

@property (nonatomic , strong) NSArray *arrPersons ;


@end
