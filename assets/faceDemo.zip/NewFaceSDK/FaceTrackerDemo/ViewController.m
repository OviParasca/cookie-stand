//
//  ViewController.m
//  FaceTrackerDemo
//
//  Created by Jack Song on 2/20/16.
//  Copyright © 2016 ReadFace. All rights reserved.
//

#import "ViewController.h"
#import <AVFoundation/AVFoundation.h>
#import "RSFaceSDK.h"
#import "CanvasView.h"

#include<AssetsLibrary/AssetsLibrary.h> 

@interface ViewController () <AVCaptureVideoDataOutputSampleBufferDelegate>

@property (nonatomic , strong) AVCaptureVideoPreviewLayer *captureVideoPreviewLayer ;


@property (nonatomic, strong) AVCaptureDevice *deviceFront;
@property (nonatomic, strong) AVCaptureSession *session;
@property (nonatomic , strong) CanvasView *viewCanvas ;
@property (nonatomic, assign) UIImagePickerControllerCameraDevice cameraPosition;
@property (nonatomic, strong) UIButton *swapCameraButton;
@end

//#define USE_DETECT

@implementation ViewController
{
    RSHandle hLicense;
    RSHandle hTracker;
    RSHandle hDetector;
}

- (void)viewDidLoad {

    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    self.view.backgroundColor = [UIColor blackColor] ;
    
    //初始化 sdk
    rsInitLicenseManager(&hLicense, "");
    if(hLicense == NULL){
        NSLog(@"error license");
    }
    
    //追踪
    rsInitFaceTrack(&hTracker, hLicense);
    
    //检测
    rsInitFaceDetect(&hDetector, hLicense);
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)dealloc
{
    rsUnInitFaceTrack(&hTracker);
    rsUnInitLicenseManager(&hLicense);
}

- (void)viewDidAppear:(BOOL)animated
{
    [super viewDidAppear:animated];

    self.session = [[AVCaptureSession alloc] init];

    // need to choose a present the same w/h ratio with screen w/h ratio
    self.session.sessionPreset = AVCaptureSessionPreset640x480;//AVCaptureSessionPresetPhoto;

    self.captureVideoPreviewLayer = [[AVCaptureVideoPreviewLayer alloc] initWithSession:self.session];
    self.captureVideoPreviewLayer.frame = CGRectMake( 0, 0, 480, 640 ) ;
//    self.captureVideoPreviewLayer.frame = self.view.bounds ;
    self.captureVideoPreviewLayer.position = self.view.center ;
    [self.captureVideoPreviewLayer setVideoGravity:AVLayerVideoGravityResizeAspectFill];
    [self.view.layer addSublayer:self.captureVideoPreviewLayer];

    self.viewCanvas = [[CanvasView alloc] initWithFrame:self.captureVideoPreviewLayer.frame];
    [self.view addSubview:self.viewCanvas] ;
    [self.view addSubview:self.swapCameraButton];
    self.viewCanvas.backgroundColor = [UIColor clearColor] ;



    NSArray *devices = [AVCaptureDevice devices];
    for (AVCaptureDevice *device in devices) {
        if ([device hasMediaType:AVMediaTypeVideo]) {

            if ([device position] == AVCaptureDevicePositionFront) {
                self.cameraPosition = UIImagePickerControllerCameraDeviceFront;
                self.deviceFront = device;
            }
        }
    }

    NSError *error = nil;
    AVCaptureDeviceInput *input = [AVCaptureDeviceInput deviceInputWithDevice:self.deviceFront error:&error];
    if (!input) {
        // Handle the error appropriately.
        NSLog(@"ERROR: trying to open camera: %@", error);
    }
    AVCaptureVideoDataOutput * dataOutput = [[AVCaptureVideoDataOutput alloc] init];
    [dataOutput setAlwaysDiscardsLateVideoFrames:YES];
    //
    [dataOutput setVideoSettings:[NSDictionary dictionaryWithObject:[NSNumber numberWithInt:kCVPixelFormatType_32BGRA] forKey:(id)kCVPixelBufferPixelFormatTypeKey]];

    dispatch_queue_t queue = dispatch_queue_create("bufferQueue", NULL);
    [dataOutput setSampleBufferDelegate:self queue:queue];

    [self.session beginConfiguration];
    if ([self.session canAddInput:input]) {
        [self.session addInput:input];
    }
    if ([self.session canAddOutput:dataOutput]) {
        [self.session addOutput:dataOutput];
    }
    [self.session commitConfiguration];

    [self.session startRunning];
}

//切换前后摄像头
-(void)toggleSwapCamera{
    if (self.cameraPosition == UIImagePickerControllerCameraDeviceRear) {
        self.cameraPosition = UIImagePickerControllerCameraDeviceFront;
    }else{
        self.cameraPosition = UIImagePickerControllerCameraDeviceRear;
    }

    if ([self.deviceFront lockForConfiguration:nil]) {
        if ([UIImagePickerController isCameraDeviceAvailable:self.cameraPosition]) {
            for(AVCaptureDevice *d in [AVCaptureDevice devicesWithMediaType:AVMediaTypeVideo]){
                if (self.cameraPosition == UIImagePickerControllerCameraDeviceFront) {
                    if ([d position] == AVCaptureDevicePositionFront) {
                        self.deviceFront = d;
                    }
                }else{
                    if ([d position] == AVCaptureDevicePositionBack) {
                        self.deviceFront = d;
                    }
                }
            }
        }
    }
    [self.deviceFront unlockForConfiguration];

    if ([self.deviceFront lockForConfiguration:nil]) {
        [self.deviceFront setActiveVideoMaxFrameDuration:CMTimeMake(10, 300)];
        [self.deviceFront setActiveVideoMinFrameDuration:CMTimeMake(10, 300)];
        [self.deviceFront unlockForConfiguration];
    }
    for(AVCaptureInput *inputDevice in self.session.inputs){
        [self.session removeInput:inputDevice];
    }
    NSError *error = nil;
    AVCaptureDeviceInput *deviceInput = [AVCaptureDeviceInput deviceInputWithDevice:self.deviceFront error:&error];
    if ([self.session canAddInput:deviceInput]) {
        [self.session addInput:deviceInput];
    }
}


-(void)captureOutput:(AVCaptureOutput *)captureOutput didOutputSampleBuffer:(CMSampleBufferRef)sampleBuffer fromConnection:(AVCaptureConnection *)connection {

    if(!hTracker){
        NSLog(@"error null tracker");
        return;
    }
//    freeFaceTracker(&hTracker);
//    initFaceTracker(&hTracker, "");


    CVImageBufferRef pixelBuffer = (CVImageBufferRef)CMSampleBufferGetImageBuffer(sampleBuffer);
    CVPixelBufferLockBaseAddress(pixelBuffer, 0);
    unsigned char *baseAddress = CVPixelBufferGetBaseAddress(pixelBuffer);

    rs_face *pFaceRectID = NULL ;
    int iCount = 0;

    int iWidth  = (int)CVPixelBufferGetWidth(pixelBuffer);
    int iHeight = (int)CVPixelBufferGetHeight(pixelBuffer);
    int bytesPerRow = (int)CVPixelBufferGetBytesPerRow(pixelBuffer);

    clock_t start = clock();

#ifdef USE_DETECT
    //检测face
    int iRet = rsRunFaceDetect(hDetector, baseAddress, PIX_FORMAT_BGRA8888, iWidth, iHeight, bytesPerRow, RS_IMG_CLOCKWISE_ROTATE_0, &pFaceRectID, &iCount);
#else
    //追踪face
    int iRet = rsRunFaceTrack(hTracker, baseAddress, PIX_FORMAT_BGRA8888, iWidth, iHeight, bytesPerRow, RS_IMG_CLOCKWISE_ROTATE_0, &pFaceRectID, &iCount);
#endif

    clock_t end = clock();

    NSLog(@" %d cost time: %f", iRet, (end-start)/(double)CLOCKS_PER_SEC);
    
    if ( iRet == 0 && iCount > 0 ) {

        NSMutableArray *arrPersons = [NSMutableArray array] ;

        for (int i = 0; i < iCount ; i ++) {

            rs_face rectIDMain = pFaceRectID[i] ;

            NSMutableArray *arrStrPoints = [NSMutableArray array] ;
            
            //面部特征点
            rs_point *facialPoints = rectIDMain.landmarks21;

//            NSLog(@"yaw %d", rectIDMain.yaw);
            NSLog(@"conf: %f", rectIDMain.confidence);

            float x_scale = 1.0f * self.viewCanvas.frame.size.width / iHeight;
            float y_scale = 1.0f * self.viewCanvas.frame.size.height / iWidth;

            for(int i = 0; i < 21; i ++) {

                if (self.cameraPosition == UIImagePickerControllerCameraDeviceFront) {
                    // front camera
                    [arrStrPoints addObject:NSStringFromCGPoint(CGPointMake(facialPoints[i].y * x_scale, facialPoints[i].x * y_scale))] ;
                }
                else{
                    // back camera
                    [arrStrPoints addObject:NSStringFromCGPoint(CGPointMake((iHeight - facialPoints[i].y) *x_scale, facialPoints[i].x * y_scale))] ;
                }
            }

            //人脸框的信息
            rs_rect rect = rectIDMain.rect ;

            CGRect rectFace ;
            if (self.cameraPosition == UIImagePickerControllerCameraDeviceFront) {
                // front camera
                rectFace = CGRectMake(rect.top * x_scale, rect.left * y_scale , rect.width * x_scale, rect.height * y_scale);
            }else{

                // back camera
                rectFace = CGRectMake((iHeight - rect.top - rect.width)*x_scale, rect.left * y_scale, rect.width * y_scale, rect.height * y_scale);
            }

            NSMutableDictionary *dicPerson = [NSMutableDictionary dictionary] ;
            [dicPerson setObject:arrStrPoints forKey:POINTS_KEY];
            [dicPerson setObject:NSStringFromCGRect(rectFace) forKey:RECT_KEY];

            [arrPersons addObject:dicPerson] ;
        }

        dispatch_async(dispatch_get_main_queue(), ^{
            [self showFaceLandmarksAndFaceRectWithPersonsArray:arrPersons];
        } ) ;

    } else {
        dispatch_async(dispatch_get_main_queue(), ^{
            [self hideFace];
        } ) ;
    }
#ifdef USE_DETECT
    releaseFaceDetectResult(pFaceRectID, iCount);
#else
    releaseFaceTrackResult(pFaceRectID, iCount);
#endif
    CVPixelBufferUnlockBaseAddress(pixelBuffer, 0);
}


- (void) showFaceLandmarksAndFaceRectWithPersonsArray:(NSMutableArray *)arrPersons
{
    if (self.viewCanvas.hidden) {
        self.viewCanvas.hidden = NO ;
    }
    self.viewCanvas.arrPersons = arrPersons ;
    [self.viewCanvas setNeedsDisplay] ;
}

- (void) hideFace {
    if (!self.viewCanvas.hidden) {
        self.viewCanvas.hidden = YES ;
    }
}

-(UIButton *)swapCameraButton{
    if (!_swapCameraButton) {
        _swapCameraButton = [[UIButton alloc] initWithFrame:self.view.bounds];
        [_swapCameraButton addTarget:self action:@selector(toggleSwapCamera) forControlEvents:UIControlEventTouchUpInside];
    }
    return _swapCameraButton;
}

@end
